// swift-tools-version: 6.0
import PackageDescription
let package = Package(name: "JournalCompatibility", platforms: [.macOS(.v14)], targets: [.executableTarget(name: "Legacy"), .executableTarget(name: "Current")])
