import Foundation

// The plan store's vocabulary. Three files back a project's plan, and each one
// has a different owner and a different lifetime:
//
// - `.throttle/plan.json` holds `Plan` — the structure. Throttle is the only
//   writer.
// - `.throttle/log/<taskId>.ndjson` holds `[TaskEvent]` — the truth. Append-only,
//   hash-chained, never rewritten.
// - `.throttle/state/<taskId>.json` holds `TaskState` — a projection derived from
//   the log. Deleting it loses nothing; it replays identically.
//
// The split exists so that a killed agent, a crashed app, or a counter-analysis
// run months later all read the same facts instead of trusting whatever an agent
// last claimed about itself.

// MARK: - Structure

enum TaskKind: String, Codable, Sendable, CaseIterable {
    case research, build, audit, decision
}

// One node of the plan. A "phase" is simply a task that has children — there is
// no second type, so rollup and dependency logic never has to branch on it.
struct PlanTask: Codable, Sendable, Equatable, Identifiable {
    let id: String
    var parent: String?
    var order: Int
    var title: String
    var kind: TaskKind
    var dependsOn: [String]

    /// Read and displayed by lot A, interpreted by lot D (dispatcher).
    var runtimeHint: String?
    /// Read and displayed by lot A, interpreted by lot E (counter-analysis).
    /// When set, a green check sends a candidate to review rather than done.
    var sotaGate: Bool
    /// Overrides `Plan.verify` for this task, when set.
    var verify: String?
    /// Independent requirements for integration, never inferred from a result bundle.
    var verificationContract: WorkflowVerificationContract?
    /// A versioned workflow guide. It adds evidence obligations, never authority.
    var recipe: WorkflowRecipeReference?
    /// The complete, versioned task boundary. Legacy fields above remain decodable.
    var workContract: WorkflowWorkContract?

    init(id: String, parent: String? = nil, order: Int = 0, title: String,
         kind: TaskKind = .build, dependsOn: [String] = [],
         runtimeHint: String? = nil, sotaGate: Bool = false, verify: String? = nil,
         verificationContract: WorkflowVerificationContract? = nil,
         recipe: WorkflowRecipeReference? = nil,
         workContract: WorkflowWorkContract? = nil) {
        self.id = id
        self.parent = parent
        self.order = order
        self.title = title
        self.kind = kind
        self.dependsOn = dependsOn
        self.runtimeHint = runtimeHint
        self.sotaGate = sotaGate
        self.verify = verify
        self.verificationContract = verificationContract
        self.recipe = recipe
        self.workContract = workContract
    }

    // Hand-written so a plan authored by a human or by an agent survives missing
    // optional keys and an unrecognised `kind` instead of failing the whole file.
    init(from decoder: Decoder) throws {
        let box = try decoder.container(keyedBy: CodingKeys.self)
        id = try box.decode(String.self, forKey: .id)
        parent = try box.decodeIfPresent(String.self, forKey: .parent)
        order = try box.decodeIfPresent(Int.self, forKey: .order) ?? 0
        title = try box.decodeIfPresent(String.self, forKey: .title) ?? box.decode(String.self, forKey: .id)
        kind = TaskKind(rawValue: try box.decodeIfPresent(String.self, forKey: .kind) ?? "") ?? .build
        dependsOn = try box.decodeIfPresent([String].self, forKey: .dependsOn) ?? []
        runtimeHint = try box.decodeIfPresent(String.self, forKey: .runtimeHint)
        sotaGate = try box.decodeIfPresent(Bool.self, forKey: .sotaGate) ?? false
        verify = try box.decodeIfPresent(String.self, forKey: .verify)
        verificationContract = try box.decodeIfPresent(WorkflowVerificationContract.self, forKey: .verificationContract)
        recipe = try box.decodeIfPresent(WorkflowRecipeReference.self, forKey: .recipe)
        workContract = try box.decodeIfPresent(WorkflowWorkContract.self, forKey: .workContract)
    }

    var effectiveVerificationContract: WorkflowVerificationContract? {
        workContract?.verification ?? verificationContract
    }

    var effectiveRecipe: WorkflowRecipeReference? {
        workContract?.recipe ?? recipe
    }

    var contractIsValid: Bool {
        guard workContract?.isValid ?? true else { return false }
        if let embedded = workContract?.verification, let legacy = verificationContract,
           embedded != legacy { return false }
        if let embedded = workContract?.recipe, let legacy = recipe,
           embedded != legacy { return false }
        return true
    }
}

struct Plan: Codable, Sendable, Equatable {
    var schema: Int
    var projectId: String
    var title: String
    /// The shell command lot F runs to verify a task before integrating it.
    /// A task's own `verify` overrides this when set.
    var verify: String?
    var tasks: [PlanTask]

    init(schema: Int = 1, projectId: String, title: String,
         verify: String? = nil, tasks: [PlanTask]) {
        self.schema = schema
        self.projectId = projectId
        self.title = title
        self.verify = verify
        self.tasks = tasks
    }

    init(from decoder: Decoder) throws {
        let box = try decoder.container(keyedBy: CodingKeys.self)
        schema = try box.decodeIfPresent(Int.self, forKey: .schema) ?? 1
        projectId = try box.decodeIfPresent(String.self, forKey: .projectId) ?? ""
        title = try box.decodeIfPresent(String.self, forKey: .title) ?? ""
        verify = try box.decodeIfPresent(String.self, forKey: .verify)
        tasks = try box.decodeIfPresent([PlanTask].self, forKey: .tasks) ?? []
    }

    func task(_ id: String) -> PlanTask? { tasks.first { $0.id == id } }

    func children(of id: String?) -> [PlanTask] {
        tasks.filter { $0.parent == id }.sorted { ($0.order, $0.id) < ($1.order, $1.id) }
    }

    var roots: [PlanTask] { children(of: nil) }

    var isLeafByID: [String: Bool] {
        let parents = Set(tasks.compactMap(\.parent))
        return Dictionary(uniqueKeysWithValues: tasks.map { ($0.id, !parents.contains($0.id)) })
    }

    /// Every leaf at or below `id`, which is what a rollup averages over. A leaf
    /// asked about itself answers with itself.
    func leaves(under id: String) -> [PlanTask] {
        let kids = children(of: id)
        guard !kids.isEmpty else { return task(id).map { [$0] } ?? [] }
        return kids.flatMap { leaves(under: $0.id) }
    }
}

// MARK: - Log

enum TaskEventType: String, Codable, Sendable {
    case claimed, progress, evidence, blocked, unblocked, completed, failed, released
    /// A worker's claim that its output is ready. Only Throttle's subsequent
    /// `checked` event may promote it to done or to counter-analysis.
    case candidateComplete = "candidate_complete"
    /// Counter-analysis verdicts. Only a runtime from a different family may emit
    /// them: a judge scoring its own family rates it higher, and self-refinement
    /// by the same model amplifies that bias rather than cancelling it.
    case verified, rejected
    /// Written by Throttle, never by an agent: the verification it ran itself, and
    /// the fast-forward it performed. They are facts about a finished task, so they
    /// do not go through ownership.
    case checked, integrated
    case verificationStarted = "verification_started"
    case verificationProcessAttached = "verification_process_attached"
    case verificationAbandoned = "verification_abandoned"
}

/// One line of a task's NDJSON log. Flat rather than a payload union, because the
/// file is meant to stay readable by a human and greppable by an agent.
struct TaskEvent: Codable, Sendable, Equatable {
    var seq: Int
    var timestamp: Date
    /// `"<runtime>:<sessionId>"`, e.g. `"codex:sess_ab"`. The runtime prefix is
    /// what the UI shows and what lot E compares against.
    var author: String
    var type: TaskEventType
    /// sha256 of the previous raw line; nil on the first event.
    var prev: String?

    var pct: Int?
    var note: String?
    var kind: String?
    var ref: String?
    var reason: String?
    var summary: String?
    var missionID: String?
    var authorityGrantID: UUID?
    /// Set only on `checked`: whether Throttle's own verify command passed. The
    /// wire key stays the short `ok` (log brevity is a spec decision); the Swift
    /// name is spelled out because SwiftLint's `identifier_name` floors at 3
    /// characters.
    var passed: Bool?
    /// Nil on legacy events: absence is not a stronger level of proof.
    var receipt: WorkflowEvidenceReceipt?
    /// Recipe and instruction identities captured at claim time.
    var recipeID: WorkflowRecipeID?
    var recipeDigest: String?
    var instructionSnapshotDigest: String?
    var workContractDigest: String?
    /// Local admission proof only. It does not claim provider-side enforcement.
    var budgetReservationID: UUID?
    var budgetLedgerRevision: Int?
    var reviewReport: WorkflowReviewReport?
    /// Nil on legacy events. Retries with the same identity cannot append twice.
    var eventID: UUID?
    var verificationLease: TaskVerificationLease?
    var verificationProcess: TaskVerificationProcess?

    init(seq: Int, timestamp: Date, author: String, type: TaskEventType, prev: String? = nil,
         pct: Int? = nil, note: String? = nil, kind: String? = nil, ref: String? = nil,
         reason: String? = nil, summary: String? = nil, missionID: String? = nil,
         passed: Bool? = nil, receipt: WorkflowEvidenceReceipt? = nil,
         recipeID: WorkflowRecipeID? = nil, recipeDigest: String? = nil,
         instructionSnapshotDigest: String? = nil, workContractDigest: String? = nil,
         budgetReservationID: UUID? = nil, budgetLedgerRevision: Int? = nil,
         reviewReport: WorkflowReviewReport? = nil,
         eventID: UUID? = UUID()) {
        self.seq = seq
        self.timestamp = timestamp
        self.author = author
        self.type = type
        self.prev = prev
        self.pct = pct
        self.note = note
        self.kind = kind
        self.ref = ref
        self.reason = reason
        self.summary = summary
        self.missionID = missionID
        self.passed = passed
        self.receipt = receipt
        self.recipeID = recipeID
        self.recipeDigest = recipeDigest
        self.instructionSnapshotDigest = instructionSnapshotDigest
        self.workContractDigest = workContractDigest
        self.budgetReservationID = budgetReservationID
        self.budgetLedgerRevision = budgetLedgerRevision
        self.reviewReport = reviewReport
        self.eventID = eventID
    }

    /// The runtime half of `by`, used for display and for lot E's
    /// opposite-model check.
    var runtime: String { String(author.prefix(while: { $0 != ":" })) }

    // The wire format keeps the short keys: an NDJSON log is read by humans and
    // grepped by agents, where `at`/`by`/`ok` earn their brevity even though the
    // Swift-side names spell them out.
    enum CodingKeys: String, CodingKey {
        case seq, prev, pct, note, kind, ref, reason, summary, missionID, type, receipt, eventID
        case recipeID, recipeDigest, instructionSnapshotDigest
        case workContractDigest
        case budgetReservationID, budgetLedgerRevision
        case reviewReport, verificationLease, verificationProcess, authorityGrantID
        case passed = "ok"
        case timestamp = "at"
        case author = "by"
    }
}

// MARK: - Projection

enum TaskStatus: String, Codable, Sendable {
    case pending, blocked, claimed, running, candidate, review, done, failed, integrated
}

/// The verification Throttle ran, stamped with the two SHAs it was true for. It
/// stops being green on its own the moment either side moves — which is the merge
/// queue's guarantee without the queue.
struct TaskCheck: Codable, Sendable, Equatable {
    let passed: Bool
    let stamp: String
    let ranAt: Date
    var receipt: WorkflowEvidenceReceipt?

    // The wire format keeps `ok`/`at`, matching the NDJSON log's own short keys.
    enum CodingKeys: String, CodingKey {
        case stamp, receipt
        case passed = "ok"
        case ranAt = "at"
    }
}

struct TaskEvidence: Codable, Sendable, Equatable, Hashable {
    var kind: String
    var ref: String
    var timestamp: Date

    enum CodingKeys: String, CodingKey {
        case kind, ref
        case timestamp = "at"
    }
}

/// Why an event was ignored. Kept in the projection rather than dropped silently,
/// because a rejected claim is exactly the kind of thing the user needs to see
/// when two agents fight over one task.
struct RejectedEvent: Codable, Sendable, Equatable {
    enum Reason: String, Codable, Sendable {
        case notOwner, alreadyOwned, outOfOrder, terminal, sameFamily, staleVerification
    }
    var seq: Int
    var author: String
    var type: TaskEventType
    var reason: Reason

    enum CodingKeys: String, CodingKey {
        case seq, type, reason
        case author = "by"
    }
}

struct TaskState: Codable, Sendable, Equatable {
    var status: TaskStatus = .pending
    var pct: Int = 0
    var owner: String?
    var runtime: String?
    var missionID: String?
    var authorityGrantID: UUID?
    var startedAt: Date?
    var lastSeq: Int = 0
    var evidence: [TaskEvidence] = []
    var blockedReason: String?
    var summary: String?
    /// How many times counter-analysis sent this task back. The loop is capped,
    /// because "iterate until SOTA" without a ceiling is an infinite paid loop.
    var rejectionCount: Int = 0
    var verdictBy: String?
    /// False when a `prev` hash did not match — someone wrote the log without
    /// going through Throttle. A signal to surface, not a corruption to hide.
    var chainValid: Bool = true
    var rejected: [RejectedEvent] = []
    var lastCheck: TaskCheck?
    var integratedSHA: String?
    var budgetReservationID: UUID?
    var budgetLedgerRevision: Int?
    var lastReview: WorkflowReviewReport?
    var pendingVerification: TaskVerificationLease?
    var verificationProcess: TaskVerificationProcess?
}
